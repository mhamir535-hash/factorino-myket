/* Native Myket bridge for فاکتور فاکتور */
(function () {
  'use strict';

  var PRODUCT_ID = 'factor_3month2';
  var RSA_PUBLIC_KEY = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCm3axxh/4MyE4n4GXtEDpXrMHn5OcGK1HDUzMqHiko80kZYzWCD5XM3zG5tq18YxK5CPkuuUWjsTCZNYK4eA0aEcekLy1C7ed+QPbbhBTD0eGQLKayGPEsecKqaW8Gj9Qcc+QjyRPdEklPBk3ZtR3Md5WsFJ9rbdKIOoGElnaSRQIDAQAB';

  var initialized = false;
  var initializing = null;

  function getMyket() {
    try {
      if (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.Myket) {
        return window.Capacitor.Plugins.Myket;
      }
    } catch (e) {}
    return null;
  }

  async function ensureInitialized() {
    var myket = getMyket();
    if (!myket) throw new Error('Myket native plugin is not available');

    if (initialized) return myket;
    if (initializing) return initializing;

    initializing = myket.initialize({ rsaPublicKey: RSA_PUBLIC_KEY })
      .then(function () {
        initialized = true;
        return myket;
      })
      .catch(function (err) {
        initializing = null;
        throw err;
      });

    return initializing;
  }

  async function buySubscription() {
    var myket = await ensureInitialized();

    // Confirm that the subscription exists before opening the Myket payment sheet.
    var catalog = await myket.getProducts({ skus: [PRODUCT_ID] });
    if (!catalog || !catalog.products || !catalog.products.length) {
      throw new Error('Myket product not found or inactive: ' + PRODUCT_ID);
    }

    // Myket opens the native payment sheet. The HTML grant callback is
    // called ONLY after the native plugin returns a successful purchase.
    var result = await myket.purchaseProduct({
      productId: PRODUCT_ID,
      type: 'subs',
      payload: 'factorino:' + PRODUCT_ID
    });

    if (!result || !result.purchase) {
      throw new Error('Myket did not return a successful purchase');
    }

    if (typeof window.onMyketSubscriptionPurchased === 'function') {
      window.onMyketSubscriptionPurchased({
        productId: PRODUCT_ID,
        purchaseToken: result.purchase.purchaseToken || ''
      });
    }

    return result;
  }

  window.factorinoBuy = buySubscription;

  window.AndroidMyket = window.AndroidMyket || {};
  window.AndroidMyket.buySubscription = buySubscription;

  window.Myket = window.Myket || {};
  window.Myket.purchase = buySubscription;
})();
