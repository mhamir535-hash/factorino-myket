# فاکتور فاکتور — Myket Android

این مخزن شامل پروژه کامل منبع برای تبدیل HTML برنامه «فاکتور فاکتور» به APK/AAB اندروید است.

## مشخصات ثابت
- Application ID: `com.factor.factorinvoice38Y`
- Myket product ID: `factor_3month2`
- نوع خرید: `subs`
- مدت اشتراک برنامه: ۳ ماه / ۹۰ روز
- درگاه: Myket

## خرید Myket
`www/myket-bridge.js` از پلاگین native Myket استفاده می‌کند. کلید عمومی RSA ارائه‌شده برای Myket در همین فایل قرار گرفته است.
پس از باز شدن پنجره پرداخت Myket، callback برنامه فقط وقتی اجرا می‌شود که native plugin یک `purchase` موفق برگرداند. لغو یا خطا callback فعال‌سازی را اجرا نمی‌کند.

پلاگین `@salarizadi/capacitor-myket` نسخه 1.0.0 است و API آن `initialize`، `getProducts` و `purchaseProduct` با نوع `subs` را فراهم می‌کند و احراز امضای RSA را پشتیبانی می‌کند.

## ساخت خودکار در GitHub Actions
Workflow موجود در `.github/workflows/build.yml`:
1. وابستگی‌ها را نصب می‌کند.
2. پروژه Android را با Capacitor می‌سازد.
3. Myket plugin را sync می‌کند.
4. APK تستی Debug می‌سازد.
5. AAB Release می‌سازد.
6. هر دو را به عنوان Artifact منتشر می‌کند.

### نکته مهم انتشار در Myket
برای خرید واقعی، محصول `factor_3month2` باید در پنل توسعه‌دهندگان Myket برای همین Application ID فعال باشد و APK/AAB منتشرشده با امضای مورد قبول Myket ارائه شود. AAB تولیدشده توسط workflow در حالت Release بدون کلید خصوصی ناشر است؛ کلید خصوصی نباید داخل GitHub عمومی یا این ZIP قرار داده شود.

## فایل اصلی برنامه
HTML اصلی در `www/index.html` قرار دارد و ظاهر و منطق اصلی آن حفظ شده است؛ فقط bridge native در انتهای صفحه اضافه شده است.
