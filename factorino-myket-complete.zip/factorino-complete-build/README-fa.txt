پروژه کامل فاکتور فاکتور + آماده‌سازی پرداخت مایکت

این بسته شامل HTML اصلی فعلی، تنظیمات Capacitor، وابستگی مایکت و workflow ساخت اندروید است.

App ID: com.factor.factorinvoice38Y
Myket Product ID: factor_3month2
Provider: myket

مهم: فایل www/index.html همان فایل نهایی HTML است و محتوای آن برای ساخت این بسته تغییر داده نشده است.

برای ساخت Android Project و APK/AAB:
npm install
npx cap add android
npx cap sync android
npx cap build android

پرداخت واقعی مایکت نیازمند اجرای پروژه در محیط Android و تست با حساب/محصول مایکت است؛ این ZIP به‌تنهایی به معنی APK ساخته‌شده یا پرداخت تست‌شده نیست.
